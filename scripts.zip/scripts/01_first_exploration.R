setwd("C:\\Data\\Coursera\\predmachlearn-002\\programm_assigment\\predmachlearn-002")

## load data:
pml <- read.csv("data\\pml-training.csv", na.strings = c("", "NA", "#DIV/0!"))


pml.submit <- read.csv("data\\pml-testing.csv", na.strings = c("", "NA", "#DIV/0!"))

### prepare data set for submition: set the same type for some features
pml.submit$new_window <- factor(pml.submit$new_window, levels(pml$new_window))
pml.submit$cvtd_timestamp <- factor(pml.submit$cvtd_timestamp,levels(pml$cvtd_timestamp))



##
##  Exploration and data cleaning
##

## explorations 
summary(pml)

## We can see, that we have a lot of column with moslty NA values
## find not sparsed columns, with at least 10% not NA values:
not.sparsed.features <- apply(pml, 2, function (x) { mean(is.na(x))}) < 0.1 
names(pml)[not.sparsed.features]

#check again count of NA for not.sparsed.features:
# it's ok if sum = 0
sum(apply(pml[, not.sparsed.features], 2, function (x) { mean(is.na(x))}))

#check that the dataset for submition this column also have all NA values.
# it's ok if sum = 0
sum(!is.na(pml.submit[,!not.sparsed.features]))

# in fact it not obligatiry to exlude all NA features for some algorithm (random forest,decision tree), we can just replace NA to some abnormal value 
# and get the same result, but it will takes some more time.

#looks again at the not sparsed data:
summary(pml[, not.sparsed.features])
head(pml[, not.sparsed.features])

# find than X, timestampls num windows are looks like leakage features. Let's validate it
leakageFeaturesInd <- c(3,4,5,6, 7) # timestamps and others  are leackage  features. 
names(pml[, leakageFeaturesInd])



## to evaluate models create data partitions:
library(caret)
inTrain <- createDataPartition(y=pml$classe, p=0.7, list = FALSE)

## check have we all personalized data (user_name) both in the source data set and in the submition dataset
table(training$user_name, training$classe)
table(pml.submit$user_name)
# so we can use user_name column for submition


## TODO check leackage features
library(randomForest)
##

leakageFeaturesInd_WithClass <-  c(leakageFeaturesInd, c(160))
names(pml)[leakageFeaturesInd_WithClass]
training.leakage <- pml[inTrain,leakageFeaturesInd_WithClass]
testing.leakage <- pml[-inTrain,leakageFeaturesInd_WithClass]

rf.model.leakage <- randomForest(classe ~ ., data = training.leakage, ntree=100, do.trace=1, importance=TRUE)

predictions.leakage  <- predict(rf.model.leakage ,newdata=testing[,leakageFeaturesInd]); table(predictions.leakage )
confusionMatrix(predictions.leakage ,testing$classe)
prediction.submit.leakage <- predict(rf.model.leakage, newdata=pml.submit[, leakageFeaturesInd]); prediction.submit.leakage 

## So, we have Accuracy = 100% without using any measures from sensors, so it's seems we have 5 columns with information leakage. Exlude them. 
## And remember prediction for 20 rows for submitting to compare later with "honest" model result







(not.sparsed.features)

## prepare cleared features vector, removing X column, leackage features and sparsed column
t <- rep(TRUE, dim(pml)[2])
t[leakageFeaturesInd] <- FALSE    # remove leakage features
t[1] <- FALSE                     # remove X column 
cleared.features <- t & not.sparsed.features
# result features vector :
names(pml[,cleared.features])


##### Prepare training and testing data set:

training <- pml[inTrain, cleared.features]
testing <- pml[-inTrain, cleared.features]
dim(training); dim(testing)


## we have not any suggestion about linerity, so use high accuracy method for non-linear data Random Forest

modFit <- train(classe ~., method="rf", ntree= 500, importance=TRUE, data = training, trControl=trainControl(method = "cv", number = 4, verboseIter=T))
## it takes 4*2 execution of randomForest algorithm
modFit

rf.model <- modFit$finalModel;

predictions <- predict(rf.model,newdata=testing);    table(predictions)
confusionMatrix(predictions,testing$classe)

importance <- data.frame(rf.model$importance);  
importance.ordered <- importance[order(-importance$MeanDecreaseAccuracy),]

importance[order(-importance$MeanDecreaseGini),]

barplot(importance.ordered$MeanDecreaseAccuracy, main = "features importance (Accuracy) hist")
data.frame(predictor = rownames(importance.ordered), importance = importance.ordered$MeanDecreaseAccuracy)


## generate submitions:

prediction.submit <- predict(rf.model,newdata=pml.submit[, cleared.features])
prediction.submit

# compare result with leakage prediction: 
prediction.submit.leakage 

###### answers

answers = as.character(prediction.submit)

pml_write_files = function(x){
  n = length(x)
  for(i in 1:n){
    filename = paste0("problem_id_",i,".txt")
    write.table(x[i],file=filename,quote=FALSE,row.names=FALSE,col.names=FALSE)
  }
}
pml_write_files(answers)





modFit$finalModel







#f_Ind <- c(2,3,4,5,6,7)
f_Ind <- setdiff(c(1:159),leakageFeaturesInd)
f_Ind_class <-  c(f_Ind, c(160))
names(pml)[f_Ind_class]
summary(training[, f_Ind_class])

rf.model <- randomForest(classe ~ ., data = training[,f_Ind_class], ntree=100, do.trace=1, importance=TRUE, na.action=na.omit)
importance <- data.frame(rf.model$importance);  
dim(importance[importance$MeanDecreaseAccuracy > 0.001,])
importance[order(-importance$MeanDecreaseAccuracy),]
importance[order(-importance$MeanDecreaseAccuracy),]

predictions <- predict(rf.model,newdata=testing[,f_Ind_class]);   table(predictions)
confusionMatrix(predictions,testing$classe)

prediction.submit <- predict(rf.model,newdata=pml.submit[, f_Ind])
prediction.submit
prediction.submit.leakage 








names(pml.submit)
##

names(pml)
pml.submit[,c(1:3,160)]
training[training$raw_timestamp_part_1==1323095002,c(1:3,160)]
testing[testing$raw_timestamp_part_1==1323095002,c(1:3,160)]
pml.submit[pml.submit$raw_timestamp_part_1==1323095002,c(1:3,160)]



